import { Test, TestingModule } from '@nestjs/testing';
import { AlbumController } from './album.controller';
import { AlbumService } from './album.service';

describe('Album Controller', () => {
  let controller: AlbumController;
  let service: AlbumService;
  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [AlbumController],
      providers: [
        {
          provide: AlbumService,
          useValue: {
            findAll: jest.fn().mockResolvedValue([
              {
                name: 'Album #1',
                description: 'Description #1',
                filename: 'Filename #1',
                isPublish: true,
              },
              {
                name: 'Album #2',
                description: 'Description #2',
                filename: 'Filename #2',
                isPublish: true,
              },
              {
                name: 'Album #3',
                description: 'Description #3',
                filename: 'Filename #3',
                isPublish: false,
              },
            ]),
          },
        },
      ],
    }).compile();

    controller = module.get<AlbumController>(AlbumController);
    service = module.get<AlbumService>(AlbumService);
  });

  describe('findAll()', () => {
    it('should return an array of albums', () => {
      expect(controller.findAll()).resolves.toEqual([
        {
          name: 'Album #1',
          description: 'Description #1',
          filename: 'Filename #1',
          isPublish: true,
        },
        {
          name: 'Album #2',
          description: 'Description #2',
          filename: 'Filename #2',
          isPublish: true,
        },
        {
          name: 'Album #3',
          description: 'Description #3',
          filename: 'Filename #3',
          isPublish: false,
        },
      ]);
    });
  });
});
