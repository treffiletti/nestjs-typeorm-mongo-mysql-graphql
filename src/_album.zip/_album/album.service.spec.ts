import { Test, TestingModule } from '@nestjs/testing';
import { getRepositoryToken } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Album } from './album.entity';
import { AlbumService } from './album.service';

describe('CatService', () => {
  let service: AlbumService;
  let repository: Repository<Album>;

  const albumsArray = [
    {
      name: 'Album #1',
      description: 'Description #1',
      filename: 'Filename #1',
      isPublish: true,
    },
    {
      name: 'Album #2',
      description: 'Description #2',
      filename: 'Filename #2',
      isPublish: true,
    },
  ];

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        AlbumService,
        {
          provide: getRepositoryToken(Album),
          useValue: {
            find: jest.fn().mockResolvedValue(albumsArray),
          },
        },
      ],
    }).compile();

    service = module.get<AlbumService>(AlbumService);
    repository = module.get<Repository<Album>>(getRepositoryToken(Album));
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  it('should return an array of albums', async () => {
    const albums = await service.findAll();
    expect(albums).toEqual(albumsArray);
  });
});
