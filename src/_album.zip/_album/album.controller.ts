import { Controller, Get, Post } from '@nestjs/common';
import { AlbumService } from './album.service';
import { Album } from './album.entity';

@Controller('album')
export class AlbumController {
  constructor(private readonly albumService: AlbumService) {}

  @Get()
  findAll(): Promise<Album[]> {
    return this.albumService.findAll();
  }

  @Post()
  async create(): Promise<Album[]> {
    try {
      const data2 = {
        name: 'album 456',
        description: 'Some album desc',
        isPublished: false,
      };
      console.log(`🎨  ~ album.controller.ts ~ line 16 ~ data`, data2);
      return await this.albumService.create(data2);
    } catch (error) {
      console.warn(`🔥 album.controller.ts ~ line 27 ~ error`, error);
    }
  }
}
