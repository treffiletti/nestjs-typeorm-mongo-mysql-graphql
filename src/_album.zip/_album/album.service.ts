import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Album } from './album.entity';

@Injectable()
export class AlbumService {
  constructor(
    @InjectRepository(Album)
    private albumRepository: Repository<Album>,
  ) {}

  async findAll(): Promise<Album[]> {
    return this.albumRepository.find();
  }

  // async findOne(id: string): Promise<Album> {
  //   return await this.albumRepository.findOne(id);
  // }
  // findOne(id): Promise<Album> {
  //   // console.log("OPTIONS", findOneOptions<Album>);
  //   return this.albumRepository.findOne({
  //     where: {
  //       id,
  //     },
  //   });
  // }

  create(data): Promise<Album[]> {
    try {
      console.log(`🎨  ~ file: album.service.ts ~ line 18 ~ albums`, data);
      return this.albumRepository.create(data);
    } catch (error) {
      console.warn(`🔥 album.service.ts ~ line 34 ~ error`, error);
    }
  }

  // async remove(id: string): Promise<void> {
  //   await this.albumRepository.delete(id);
  // }
}
