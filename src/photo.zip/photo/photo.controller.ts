import { Controller, Get, Post, Body } from '@nestjs/common';
import { PhotoService } from './photo.service';
import { Photo } from './photo.entity';

@Controller('photo')
export class PhotoController {
  constructor(private readonly photoService: PhotoService) {}

  @Get()
  findAll(): Promise<Photo[]> {
    return this.photoService.findAll();
  }

  @Post()
  async create(@Body() data) {
    const photo = await this.photoService.create(data);
    console.log('🎨  ~ file: photo.controller.ts ~ line 17 ~ photo', photo);
    return photo;
    return {
      message: 'This action adds a new photo',
      photo: photo,
    };
  }
}
