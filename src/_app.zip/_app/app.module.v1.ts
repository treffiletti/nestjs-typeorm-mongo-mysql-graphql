import { Module } from '@nestjs/common';
import { Connection } from 'typeorm';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AlbumModule } from './album/album.module';
import { Album } from './album/album.entity';
// import { PhotoModule } from './photo/photo.module';
// import { Photo } from './photo/photo.entity';

// const mysqlOptions = {
//   // ...dbOptions,
//   type: 'mysql',
//   host: 'localhost',
//   port: 3306,
//   username: 'root',
//   password: '123456',
//   database: 'nest-sandbox-031821',
//   entities: [Album],
//   // synchronize: true,
// };

@Module({
  imports: [
    TypeOrmModule.forRoot({
      type: 'mysql',
      host: 'localhost',
      port: 3306,
      username: 'root',
      password: '123456',
      database: 'nest-sandbox-031821',
      entities: [Album],
      autoLoadEntities: true,
      synchronize: true,
    }),
    // TypeOrmModule.forRoot({
    //   ...mysqlOptions,
    //   // host: 'user_db_host',
    //   // entities: [User],
    // }),
    // TypeOrmModule.forRoot({
    //   ...mongoOptions,
    //   name: 'albumsConnection',
    //   // host: 'album_db_host',
    //   // entities: [Album],
    // }),
    AlbumModule,
    // PhotoModule,
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {
  constructor(private connection: Connection) {}
}

// const dbOptions = {
//   database: 'nest-sandbox-031821',
//   host: 'localhost',
//   // entities: ['src/**/**.entity.ts'],
//   synchronize: true,
// };

// const mongoOptions = {
//   ...dbOptions,
//   type: 'mongodb',
//   entities: [Album],
//   // port: 27017,
// };
